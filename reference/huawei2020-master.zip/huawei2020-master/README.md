# huawei2020
华为软件精英挑战赛2020，一起加油吧
## 第三版代码（广搜剪枝+深搜搜索）: [main_v2.py](https://github.com/gao793583308/huawei2020/blob/master/main_v2.py)
![Image text](https://github.com/gao793583308/huawei2020/blob/master/pic/reuslt3.jpg)  
todo:尝试改成c++，有没有大佬教教我怎么读图之类的基本操作
## 第二版代码（深搜）: [main_v1.py](https://github.com/gao793583308/huawei2020/blob/master/main_v1.py)
![Image text](https://github.com/gao793583308/huawei2020/blob/master/pic/result2.jpg)  
### [视频讲解](https://m.ixigua.com/group/6815115124836139535/app=video_article&timestamp=1587112931&utm_source=copy_link&utm_medium=android&utm_campaign=client_share)
## 第一版代码（广搜+剪枝）: [Main.py](https://github.com/gao793583308/huawei2020/blob/master/Main.py)  
缺点：1.广搜7层节点数可能很多，速度慢。2.python天生弊端？优化中
![Image text](https://github.com/gao793583308/huawei2020/blob/master/pic/result1.jpg)  
